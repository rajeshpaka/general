import java.util.Map;

public interface Converter
{
  public String converter( String[] string, Map<String, String> mappings );
}

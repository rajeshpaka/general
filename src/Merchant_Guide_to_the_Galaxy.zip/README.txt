To ease the process of running this program, i didn't use packages.

To compile and run the code use the below commands. It generates the class files in the same directory. 
input.txt is already inthe same directory.:

javac Solution.java
java Solution

